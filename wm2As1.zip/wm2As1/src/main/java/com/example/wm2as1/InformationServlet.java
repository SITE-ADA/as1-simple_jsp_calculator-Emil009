package com.example.wm2as1;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "InformationServlet", value = "/InformationServlet")
public class InformationServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        req.setAttribute("entered",getBrowser(req));
        req.setAttribute("system",getOS());
        RequestDispatcher requestDispatcher = req
                .getRequestDispatcher("/information.jsp");
        requestDispatcher.forward(req, resp);
    }

    public String getBrowser(HttpServletRequest request){
        return request.getHeader("user-agent");
    }
    public String getOS() {
        return System.getProperty("os.name");
    }
}

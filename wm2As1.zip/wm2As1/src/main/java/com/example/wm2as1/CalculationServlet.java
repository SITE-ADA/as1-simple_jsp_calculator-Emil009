package com.example.wm2as1;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;

@WebServlet(name = "CalculationServlet", value = "/CalculationServlet")
public class CalculationServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        RequestDispatcher requestDispatcher = request
                .getRequestDispatcher("/calculate.jsp");
        requestDispatcher.forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String op = request.getParameter("op");
        try {
            Double par1 = Double.parseDouble(request.getParameter("digit1"));
            Double par2 = Double.parseDouble(request.getParameter("digit2"));
            String res = getResult(par1,par2,op);
            if (res.equals("noZero"))
                request.setAttribute("result", "Digit2 must not be zero!!");
            else if (res.equals("null"))
                request.setAttribute("result", "Enter digits!! ");
            else
                request.setAttribute("result", "Our result is "+res);
        }
        catch (Exception errorhandler){
            request.setAttribute("result", "Enter only digits!!");
        }
        RequestDispatcher requestDispatcher = request
                .getRequestDispatcher("/calculate.jsp");
        requestDispatcher.forward(request, response);
    }


    public String getResult(Double pr1, Double pr2, String op){
        Double res = 0.0;
        if (pr1==null||pr2==null)
            return "null";
        if (pr2 == 0)
            return "noZero";
        switch (op){
            case "add":
                res = pr1 + pr2;
                break;
            case "subtract":
                res = pr1 - pr2;
                break;
            case "multiply":
                res = pr1 * pr2;
                break;
            case "divide":
                res = pr1 / pr2;
            default:
                break;
        }
        return res.toString();
    }
}
